from flask import Flask, render_template, request, jsonify
import datetime
import threading
import time

app = Flask(__name__)

alarm_time = None


def check_alarm():
    global alarm_time
    while True:
        if alarm_time:
            now = datetime.datetime.now()
            if now.hour == alarm_time[0] and now.minute == alarm_time[1]:
                print("Wake up! It's time!")
                alarm_time = None
        time.sleep(10)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/set_alarm", methods=["POST"])
def set_alarm():
    global alarm_time
    data = request.json
    alarm_hour = int(data["hour"])
    alarm_minute = int(data["minute"])
    alarm_time = (alarm_hour, alarm_minute)
    return jsonify(success=True)


if __name__ == "__main__":
    threading.Thread(target=check_alarm, daemon=True).start()
    app.run(debug=True)
