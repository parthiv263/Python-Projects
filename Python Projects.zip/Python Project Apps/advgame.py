def start_game():
    print("Welcome to the Text-Based Adventure Game!")
    print("You find yourself standing at the entrance of a dark cave.")
    print("Do you want to enter the cave or walk away?")

    choice = input("Type 'enter' to enter the cave or 'walk' to walk away: ").lower()

    if choice == "enter":
        enter_cave()
    elif choice == "walk":
        walk_away()
    else:
        print("Invalid choice. Please type 'enter' or 'walk'.")
        start_game()


def enter_cave():
    print("\nYou enter the cave and find yourself in a dimly lit tunnel.")
    print("You see a light at the end of the tunnel.")
    print("Do you want to walk towards the light or explore the tunnel?")

    choice = input(
        "Type 'light' to walk towards the light or 'explore' to explore the tunnel: "
    ).lower()

    if choice == "light":
        walk_towards_light()
    elif choice == "explore":
        explore_tunnel()
    else:
        print("Invalid choice. Please type 'light' or 'explore'.")
        enter_cave()


def walk_away():
    print("\nYou decide to walk away from the cave.")
    print("As you walk away, you stumble upon a hidden treasure chest!")
    print("Congratulations! You found the hidden treasure and won the game!")


def walk_towards_light():
    print("\nYou walk towards the light and find a hidden underground lake.")
    print("Do you want to swim across the lake or go back?")

    choice = input("Type 'swim' to swim across the lake or 'back' to go back: ").lower()

    if choice == "swim":
        swim_across_lake()
    elif choice == "back":
        enter_cave()
    else:
        print("Invalid choice. Please type 'swim' or 'back'.")
        walk_towards_light()


def explore_tunnel():
    print("\nYou explore the tunnel and encounter a sleeping dragon.")
    print("Do you want to sneak past the dragon or fight it?")

    choice = input(
        "Type 'sneak' to sneak past the dragon or 'fight' to fight it: "
    ).lower()

    if choice == "sneak":
        sneak_past_dragon()
    elif choice == "fight":
        fight_dragon()
    else:
        print("Invalid choice. Please type 'sneak' or 'fight'.")
        explore_tunnel()


def swim_across_lake():
    print("\nYou swim across the lake and find a small island with a treasure chest.")
    print("Congratulations! You found the hidden treasure and won the game!")


def sneak_past_dragon():
    print("\nYou successfully sneak past the dragon and find a hidden treasure chest.")
    print("Congratulations! You found the hidden treasure and won the game!")


def fight_dragon():
    print("\nYou try to fight the dragon, but it wakes up and defeats you.")
    print("Game Over. Better luck next time!")


start_game()
