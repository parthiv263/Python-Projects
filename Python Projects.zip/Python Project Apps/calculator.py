print("Welcome to the Calculator")

# input numbers
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

# input operator
print("Choose the operation you want to perform:")
operator = input("Enter the operator ('+', '-', '*', '/', '%'): ")

if operator == "+":
    print("Addition =", num1 + num2)
elif operator == "-":
    print("Subtraction =", num1 - num2)
elif operator == "*":
    print("Multiplication =", num1 * num2)
elif operator == "%":
    print("Remainder =", num1 % num2)
elif operator == "/":
    if num2 == 0:
        print("Division is not possible here")
    else:
        print("Division =", num1 / num2)
else:
    print("Invalid operator. Please use one of the following: '+', '-', '*', '/', '%'")
