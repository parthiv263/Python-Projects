import turtle
import random

screen = turtle.Screen()
screen.setup(800, 800)
screen.title("Maze Generator and Solver")
screen.tracer(0)

maze_drawer = turtle.Turtle()
maze_drawer.hideturtle()
maze_drawer.penup()
maze_drawer.speed(0)

solver = turtle.Turtle()
solver.hideturtle()
solver.penup()
solver.speed(1)
solver.color("red")

cell_size = 20
maze_width = 20
maze_height = 20

maze = [[1 for _ in range(maze_width)] for _ in range(maze_height)]


def carve_maze(x, y):
    maze[y][x] = 0
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
    random.shuffle(directions)

    for dx, dy in directions:
        nx, ny = x + dx * 2, y + dy * 2
        if 0 <= nx < maze_width and 0 <= ny < maze_height and maze[ny][nx] == 1:
            maze[y + dy][x + dx] = 0
            carve_maze(nx, ny)


carve_maze(0, 0)

maze[0][1] = 0
maze[maze_height - 1][maze_width - 2] = 0


def draw_maze():
    for y in range(maze_height):
        for x in range(maze_width):
            screen_x = (x - maze_width // 2) * cell_size
            screen_y = (maze_height // 2 - y) * cell_size

            if maze[y][x] == 1:
                maze_drawer.goto(screen_x, screen_y)
                maze_drawer.pendown()
                maze_drawer.begin_fill()
                for _ in range(4):
                    maze_drawer.forward(cell_size)
                    maze_drawer.right(90)
                maze_drawer.end_fill()
                maze_drawer.penup()


draw_maze()
screen.update()


def solve_maze(x, y):
    if x == maze_width - 2 and y == maze_height - 1:
        return True

    for dx, dy in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
        nx, ny = x + dx, y + dy
        if 0 <= nx < maze_width and 0 <= ny < maze_height and maze[ny][nx] == 0:
            solver.goto(
                (nx - maze_width // 2) * cell_size + cell_size // 2,
                (maze_height // 2 - ny) * cell_size - cell_size // 2,
            )
            solver.pendown()
            maze[ny][nx] = 2
            screen.update()

            if solve_maze(nx, ny):
                return True

            solver.penup()
            solver.goto(
                (x - maze_width // 2) * cell_size + cell_size // 2,
                (maze_height // 2 - y) * cell_size - cell_size // 2,
            )
            solver.pendown()
            screen.update()

    return False


solver.goto(
    (-maze_width // 2 + 1) * cell_size + cell_size // 2,
    (maze_height // 2) * cell_size - cell_size // 2,
)
solver.pendown()
solve_maze(1, 0)

screen.exitonclick()
