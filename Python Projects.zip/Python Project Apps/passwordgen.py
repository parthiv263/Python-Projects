import random
import string

length = int(input("Specify the length of your password: "))
complexity = int(input("Enter the complexity ('Easy=1', 'Medium=2', 'Hard=3'): "))

if complexity == 1:

    def generate_random_number(length):
        if length <= 0:
            raise ValueError("Length must be greater than 0")

        min_value = 10 ** (length - 1)
        max_value = (10**length) - 1

        return random.randint(min_value, max_value)

    password = generate_random_number(length)
    print("Password is:", password)

elif complexity == 2:

    def generate_pass(length):
        characters = string.ascii_letters + string.digits
        return "".join(random.choice(characters) for _ in range(length))

    password = generate_pass(length)
    print("Password is:", password)

elif complexity == 3:

    def generate_letter(length):
        characters = (
            string.ascii_letters
            + string.digits
            + string.whitespace
            + string.punctuation
        )
        return "".join(random.choice(characters) for _ in range(length))

    password = generate_letter(length)
    print("Password is:", password)

else:
    print("Invalid complexity level. Please choose 1, 2, or 3.")
