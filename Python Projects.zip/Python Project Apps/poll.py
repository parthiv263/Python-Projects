class PollingApp:
    def __init__(self, question, options):
        self.question = question
        self.options = options
        self.votes = {option: 0 for option in options}

    def display_question(self):
        print(self.question)
        for i, option in enumerate(self.options, start=1):
            print(f"{i}. {option}")

    def vote(self, option_number):
        if 1 <= option_number <= len(self.options):
            option = self.options[option_number - 1]
            self.votes[option] += 1
        else:
            print("Invalid option number!")

    def display_results(self):
        print("Poll Results:")
        for option, count in self.votes.items():
            print(f"{option}: {count} votes")

def main():
    question = "What is your favorite programming language?"
    options = ["Python", "JavaScript", "Java", "C++", "Ruby"]

    app = PollingApp(question, options)

    while True:
        app.display_question()
        try:
            choice = int(input("Enter the number of your choice (0 to quit): "))
            if choice == 0:
                break
            app.vote(choice)
        except ValueError:
            print("Please enter a valid number.")

    app.display_results()

if __name__ == "__main__":
    main()
