import pygame
import random

pygame.init()

WIDTH = 800
HEIGHT = 600
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pong")

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

PADDLE_WIDTH = 15
PADDLE_HEIGHT = 90

BALL_SIZE = 15


class Paddle:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, PADDLE_WIDTH, PADDLE_HEIGHT)
        self.speed = 5

    def move(self, up=True):
        if up:
            self.rect.y -= self.speed
        else:
            self.rect.y += self.speed
        self.rect.clamp_ip(window.get_rect())

    def draw(self):
        pygame.draw.rect(window, WHITE, self.rect)


class Ball:
    def __init__(self):
        self.rect = pygame.Rect(
            WIDTH // 2 - BALL_SIZE // 2,
            HEIGHT // 2 - BALL_SIZE // 2,
            BALL_SIZE,
            BALL_SIZE,
        )
        self.dx = random.choice([-4, 4])
        self.dy = random.choice([-4, 4])

    def move(self):
        self.rect.x += self.dx
        self.rect.y += self.dy

        if self.rect.top <= 0 or self.rect.bottom >= HEIGHT:
            self.dy *= -1

    def reset(self):
        self.rect.center = (WIDTH // 2, HEIGHT // 2)
        self.dx = random.choice([-4, 4])
        self.dy = random.choice([-4, 4])

    def draw(self):
        pygame.draw.rect(window, WHITE, self.rect)


player = Paddle(50, HEIGHT // 2 - PADDLE_HEIGHT // 2)
opponent = Paddle(WIDTH - 50 - PADDLE_WIDTH, HEIGHT // 2 - PADDLE_HEIGHT // 2)
ball = Ball()

font = pygame.font.Font(None, 36)

clock = pygame.time.Clock()
player_score = 0
opponent_score = 0
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_UP]:
        player.move(up=True)
    if keys[pygame.K_DOWN]:
        player.move(up=False)

    if opponent.rect.centery < ball.rect.centery:
        opponent.move(up=False)
    elif opponent.rect.centery > ball.rect.centery:
        opponent.move(up=True)

    ball.move()

    if ball.rect.colliderect(player.rect) or ball.rect.colliderect(opponent.rect):
        ball.dx *= -1

    if ball.rect.left <= 0:
        opponent_score += 1
        ball.reset()
    elif ball.rect.right >= WIDTH:
        player_score += 1
        ball.reset()

    window.fill(BLACK)
    player.draw()
    opponent.draw()
    ball.draw()

    player_text = font.render(str(player_score), True, WHITE)
    opponent_text = font.render(str(opponent_score), True, WHITE)
    window.blit(player_text, (WIDTH // 4, 20))
    window.blit(opponent_text, (3 * WIDTH // 4, 20))

    pygame.draw.aaline(window, WHITE, (WIDTH // 2, 0), (WIDTH // 2, HEIGHT))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
