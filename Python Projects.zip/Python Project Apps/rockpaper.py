import random


def get_computer_choice():
    return random.randint(1, 3)


def get_choice_name(choice):
    return {1: "rock", 2: "paper", 3: "scissors"}.get(choice, "invalid")


def determine_winner(user, computer):
    if user == computer:
        return "It's a tie!", 0, 0
    if (
        (user == 1 and computer == 3)
        or (user == 2 and computer == 1)
        or (user == 3 and computer == 2)
    ):
        return "User wins!", 1, 0
    return "Computer wins!", 0, 1


user_score = 0
computer_score = 0

rounds = int(input("Enter the number of rounds you want to play with the computer: "))

for i in range(rounds):
    computer_no = get_computer_choice()
    user = int(input("Choose your input: 'rock:1', 'paper:2', 'scissors:3'\n"))

    if user not in [1, 2, 3]:
        print("Invalid input. Please enter 1, 2, or 3.")
        continue

    print(f"Computer input is: {get_choice_name(computer_no)}")
    print(f"User input is: {get_choice_name(user)}")

    result, user_points, computer_points = determine_winner(user, computer_no)
    print(result)

    user_score += user_points
    computer_score += computer_points


print("\nFinal Scores:")
print(f"User: {user_score}")
print(f"Computer: {computer_score}")
