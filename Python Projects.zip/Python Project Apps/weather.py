import requests


def fetch_weather(city, api_key):
    base_url = "https://api.openweathermap.org/data/2.5/weather"
    params = {"q": city, "units": "metric", "appid": api_key}

    try:
        response = requests.get(base_url, params=params)
        data = response.json()

        if data["cod"] == 200:
            weather_info = {
                "description": data["weather"][0]["description"],
                "temperature": data["main"]["temp"],
                "humidity": data["main"]["humidity"],
                "wind_speed": data["wind"]["speed"],
            }
            return weather_info
        else:
            print(f"Error fetching weather data: {data['message']}")
            return None

    except Exception as e:
        print(f"Error fetching weather data: {str(e)}")
        return None


def display_weather(weather_info, city):
    print(f"Weather in {city}:")
    print(f"Description: {weather_info['description']}")
    print(f"Temperature: {weather_info['temperature']} °C")
    print(f"Humidity: {weather_info['humidity']}%")
    print(f"Wind Speed: {weather_info['wind_speed']} m/s")


if __name__ == "__main__":

    api_key = "adb3234151094623e2468ec840cc670e"

    city = input("Enter city name: ")

    weather_info = fetch_weather(city, api_key)

    if weather_info:
        display_weather(weather_info, city)
